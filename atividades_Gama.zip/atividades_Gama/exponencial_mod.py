def expo_mod(base, expo, mod = 0):
    if mod < 2:
        return "impossivel calcular"
    if base == 0 and expo == 0:
        return "impossível calcular"
    
    if expo == 0: #caso base
        return 1 % mod
    
    base = base % mod

    if expo % 2 == 0:
        half = expo_mod(base, expo // 2, mod)
        return (half * half) % mod
    else:
        return (base * expo_mod(base, expo - 1, mod)) % mod
    
def main():
    print(expo_mod(2,10,5))

if __name__ == "__main__":
    main()