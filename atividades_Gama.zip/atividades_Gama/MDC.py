def MDC(a,b):
    if a==0 and b ==0:
        return "MDC indeterminado"
    elif b == 0:
        return a
    elif b>a:
        return MDC(b, a)
    return MDC(b, a % b)

print(MDC(0,0))