def exponencial(base,expoente):
    if base == 0 and expoente==0:
        return "impossível calcular"
    if expoente == 0:
        return 1
    return base*exponencial(base,expoente-1)

print(exponencial(2,1))